Role my_own_module
=========

This role create txt file


Role Variables
--------------

| vars           | description                  |
|----------------|------------------------------|
| path           | Path to created file         |
| content        | The content of created file  |


Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: my_own_module }

License
-------

MIT

Author Information
------------------

Egor Zhelobanov
